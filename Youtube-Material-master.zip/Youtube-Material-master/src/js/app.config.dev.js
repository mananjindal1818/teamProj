youtubeApp.config(['$compileProvider', function($compileProvider){
     $compileProvider.debugInfoEnabled(true);
}]);