# Youtube-Material
My naïve attempt at making a material version of Youtube using materializecss, GoogleApi and AngularJs.

## Where I started from
http://579cda6671e20a255417ab8c.youtube-material.bitballoon.com/

## Where I'm currently
http://youtube-material.bitballoon.com


## How to start:

Get node dependencies:
`npm install`
`npm install -g gulp-cli`

For minified build and run:
`gulp build`

For uniminified build with angular debug data:
`gulp`
